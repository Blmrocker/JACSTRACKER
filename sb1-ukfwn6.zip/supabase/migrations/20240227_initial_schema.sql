-- Enable necessary extensions
create extension if not exists "uuid-ossp";

-- Drop existing tables if they exist
drop table if exists public.inspection_items cascade;
drop table if exists public.inspections cascade;
drop table if exists public.clients cascade;
drop table if exists public.user_roles cascade;
drop table if exists public.company_info cascade;

-- Create company_info table
create table if not exists public.company_info (
  id uuid default uuid_generate_v4() primary key,
  name text,
  address text,
  phone text,
  email text,
  website text,
  logo_url text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Create clients table with your specified fields
create table if not exists public.clients (
  id uuid default uuid_generate_v4() primary key,
  name text not null,
  point_of_contact text,
  inspection_type text,
  frequency text,
  phone text,
  street_address text,
  city text,
  state text,
  zip_code text,
  email text,
  fax text,
  notes text,
  contract_start date,
  contract_end date,
  contract_amount numeric(10,2) default 0.00,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Create inspections table
create table if not exists public.inspections (
  id uuid default uuid_generate_v4() primary key,
  client_id uuid references public.clients(id) on delete cascade,
  inspection_date date not null,
  location text not null,
  inspector text not null,
  status text check (status in ('scheduled', 'completed', 'failed')) not null,
  notes text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Create inspection_items table
create table if not exists public.inspection_items (
  id uuid default uuid_generate_v4() primary key,
  inspection_id uuid references public.inspections(id) on delete cascade,
  item_type text not null,
  floor text,
  room text,
  equipment_type text not null,
  status text check (status in ('pass', 'fail', 'no-access')) not null,
  notes text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Create user_roles table
create table if not exists public.user_roles (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references auth.users not null,
  role text check (role in ('admin', 'tech')) not null,
  phone_number text,
  notify_renewals boolean default false,
  notify_inspections boolean default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  constraint user_roles_user_id_key unique (user_id)
);

-- Enable RLS on all tables
alter table public.company_info enable row level security;
alter table public.clients enable row level security;
alter table public.inspections enable row level security;
alter table public.inspection_items enable row level security;
alter table public.user_roles enable row level security;

-- Create indexes
create index if not exists idx_clients_name on public.clients(name);
create index if not exists idx_clients_contract_end on public.clients(contract_end);
create index if not exists idx_inspections_client_id on public.inspections(client_id);
create index if not exists idx_inspections_date on public.inspections(inspection_date);
create index if not exists idx_inspection_items_inspection_id on public.inspection_items(inspection_id);
create index if not exists idx_user_roles_user_id on public.user_roles(user_id);

-- Set up RLS policies
do $$ 
begin
  if not exists (select 1 from pg_policies where policyname = 'Allow authenticated users to view company info') then
    create policy "Allow authenticated users to view company info"
      on public.company_info for select
      using (auth.role() = 'authenticated');
  end if;

  if not exists (select 1 from pg_policies where policyname = 'Allow authenticated users to modify company info') then
    create policy "Allow authenticated users to modify company info"
      on public.company_info for all
      using (auth.role() = 'authenticated');
  end if;

  if not exists (select 1 from pg_policies where policyname = 'Allow authenticated users to view clients') then
    create policy "Allow authenticated users to view clients"
      on public.clients for select
      using (auth.role() = 'authenticated');
  end if;

  if not exists (select 1 from pg_policies where policyname = 'Allow authenticated users to modify clients') then
    create policy "Allow authenticated users to modify clients"
      on public.clients for all
      using (auth.role() = 'authenticated');
  end if;

  if not exists (select 1 from pg_policies where policyname = 'Allow authenticated users to view inspections') then
    create policy "Allow authenticated users to view inspections"
      on public.inspections for select
      using (auth.role() = 'authenticated');
  end if;

  if not exists (select 1 from pg_policies where policyname = 'Allow authenticated users to modify inspections') then
    create policy "Allow authenticated users to modify inspections"
      on public.inspections for all
      using (auth.role() = 'authenticated');
  end if;

  if not exists (select 1 from pg_policies where policyname = 'Allow authenticated users to view inspection items') then
    create policy "Allow authenticated users to view inspection items"
      on public.inspection_items for select
      using (auth.role() = 'authenticated');
  end if;

  if not exists (select 1 from pg_policies where policyname = 'Allow authenticated users to modify inspection items') then
    create policy "Allow authenticated users to modify inspection items"
      on public.inspection_items for all
      using (auth.role() = 'authenticated');
  end if;
end $$;

-- Create storage bucket for company assets
insert into storage.buckets (id, name, public)
values ('company-assets', 'company-assets', true)
on conflict (id) do nothing;

-- Set up storage policies
do $$
begin
  if not exists (select 1 from pg_policies where policyname = 'Allow authenticated users to view company assets') then
    create policy "Allow authenticated users to view company assets"
      on storage.objects for select
      using ( bucket_id = 'company-assets' and auth.role() = 'authenticated' );
  end if;

  if not exists (select 1 from pg_policies where policyname = 'Allow authenticated users to upload company assets') then
    create policy "Allow authenticated users to upload company assets"
      on storage.objects for insert
      with check (
        bucket_id = 'company-assets'
        and auth.role() = 'authenticated'
      );
  end if;
end $$;