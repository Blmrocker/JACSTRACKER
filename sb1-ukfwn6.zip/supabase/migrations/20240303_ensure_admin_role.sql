-- Ensure admin role for specific emails
INSERT INTO user_roles (user_id, role, notify_renewals, notify_inspections)
SELECT 
  au.id as user_id,
  'admin' as role,
  true as notify_renewals,
  true as notify_inspections
FROM auth.users au
WHERE au.email IN ('info@jacsfire.com', 'marcotonylopez90@gmail.com')
AND NOT EXISTS (
  SELECT 1 FROM user_roles ur WHERE ur.user_id = au.id
)
ON CONFLICT (user_id) 
DO UPDATE SET 
  role = 'admin',
  notify_renewals = true,
  notify_inspections = true;