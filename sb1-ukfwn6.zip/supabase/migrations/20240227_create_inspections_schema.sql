-- Create inspections table first
create table public.inspections (
  id uuid default uuid_generate_v4() primary key,
  client_id uuid references public.clients(id) on delete cascade,
  inspection_date date not null,
  location text not null,
  inspector text not null,
  status text check (status in ('scheduled', 'completed', 'failed')) not null,
  notes text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Create inspection_items table with proper foreign key
create table public.inspection_items (
  id uuid default uuid_generate_v4() primary key,
  inspection_id uuid references public.inspections(id) on delete cascade,
  item_number integer not null,
  building text,
  floor text,
  location text not null,
  type text not null,
  hydro_date text,
  notes text,
  status text check (status in ('pass', 'fail', 'no-access')) not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Add indexes
create index idx_inspections_client_id on public.inspections(client_id);
create index idx_inspections_date on public.inspections(inspection_date);
create index idx_inspection_items_inspection_id on public.inspection_items(inspection_id);

-- Enable RLS
alter table public.inspections enable row level security;
alter table public.inspection_items enable row level security;

-- Create policies for inspections
create policy "Users can view inspections"
  on public.inspections for select
  using (true);

create policy "Users can insert inspections"
  on public.inspections for insert
  with check (true);

create policy "Users can update inspections"
  on public.inspections for update
  using (true);

create policy "Users can delete inspections"
  on public.inspections for delete
  using (true);

-- Create policies for inspection items
create policy "Users can view inspection items"
  on public.inspection_items for select
  using (true);

create policy "Users can insert inspection items"
  on public.inspection_items for insert
  with check (true);

create policy "Users can update inspection items"
  on public.inspection_items for update
  using (true);

create policy "Users can delete inspection items"
  on public.inspection_items for delete
  using (true);

-- Add sample data
insert into public.inspections (client_id, inspection_date, location, inspector, status, notes)
select 
  id as client_id,
  current_date as inspection_date,
  'Main Building' as location,
  'John Doe' as inspector,
  'completed' as status,
  'Regular annual inspection' as notes
from public.clients
limit 1;

-- Add sample inspection items
insert into public.inspection_items (inspection_id, item_number, location, type, status)
select 
  i.id as inspection_id,
  row_number() over () as item_number,
  'Room ' || floor((random() * 500) + 1)::text as location,
  '2.5ABC' as type,
  case 
    when random() < 0.7 then 'pass'
    when random() < 0.9 then 'fail'
    else 'no-access'
  end as status
from public.inspections i
cross join generate_series(1, 5);