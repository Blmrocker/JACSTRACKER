-- Create inspection_items table
create table public.inspection_items (
  id uuid default uuid_generate_v4() primary key,
  inspection_id uuid references public.inspections(id) on delete cascade,
  item_number integer not null,
  building text,
  floor text,
  location text not null,
  type text not null,
  hydro_date text,
  notes text,
  status text check (status in ('pass', 'fail', 'no-access')) not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Add indexes
create index idx_inspection_items_inspection_id on public.inspection_items(inspection_id);

-- Set up RLS
alter table public.inspection_items enable row level security;

-- Create policies
create policy "Users can view inspection items"
  on public.inspection_items for select
  using (true);

create policy "Users can insert inspection items"
  on public.inspection_items for insert
  with check (true);

create policy "Users can update inspection items"
  on public.inspection_items for update
  using (true);

create policy "Users can delete inspection items"
  on public.inspection_items for delete
  using (true);