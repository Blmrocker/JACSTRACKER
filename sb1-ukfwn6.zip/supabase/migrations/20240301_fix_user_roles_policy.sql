-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Allow admins to view all users" ON user_roles;
DROP POLICY IF EXISTS "Allow users to view own role" ON user_roles;
DROP POLICY IF EXISTS "Allow admins to create users" ON user_roles;
DROP POLICY IF EXISTS "Allow admins to update users" ON user_roles;
DROP POLICY IF EXISTS "Allow admins to delete users" ON user_roles;

-- Create new policies without recursion
CREATE POLICY "admin_select_policy"
ON user_roles FOR SELECT
USING (
  auth.uid() IN (
    SELECT user_id FROM user_roles WHERE role = 'admin'
  ) OR auth.uid() = user_id
);

CREATE POLICY "admin_insert_policy"
ON user_roles FOR INSERT
WITH CHECK (
  auth.uid() IN (
    SELECT user_id FROM user_roles WHERE role = 'admin'
  )
);

CREATE POLICY "admin_update_policy"
ON user_roles FOR UPDATE
USING (
  auth.uid() IN (
    SELECT user_id FROM user_roles WHERE role = 'admin'
  )
);

CREATE POLICY "admin_delete_policy"
ON user_roles FOR DELETE
USING (
  auth.uid() IN (
    SELECT user_id FROM user_roles WHERE role = 'admin'
  )
);