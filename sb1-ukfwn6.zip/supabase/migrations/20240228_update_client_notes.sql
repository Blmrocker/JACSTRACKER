-- Update client notes with installation details
UPDATE clients 
SET notes = CASE name
    WHEN 'Quest Diagnostics' THEN 'Installed 2-5#ABC 2024'
    WHEN 'Alejandro''s' THEN 'Installed 2-5#ABC 2024'
    WHEN 'O''Reilly' THEN 'Installed 1-10#abc, 3-5#abc'
    WHEN 'The Beauty Box' THEN 'Installed 1-5#abc'
    WHEN 'Cavemen Barbershop' THEN 'Installed 2-5#ABC'
    WHEN 'Valley Medical Center' THEN 'Multiple buildings, requires coordination. Installed 5-10#ABC, 3-5#ABC'
    WHEN 'Grand Hotel & Suites' THEN '15 story building. Installed 10-10#ABC, 15-5#ABC'
    WHEN 'Riverside School District' THEN 'Multiple schools in district. Installed 20-5#ABC'
    WHEN 'City Mall' THEN 'High traffic areas. Installed 8-10#ABC, 12-5#ABC'
    WHEN 'Tech Solutions Inc' THEN 'Server rooms require special attention. Installed 4-5#ABC, 2-10#ABC'
END
WHERE name IN (
    'Quest Diagnostics',
    'Alejandro''s',
    'O''Reilly',
    'The Beauty Box',
    'Cavemen Barbershop',
    'Valley Medical Center',
    'Grand Hotel & Suites',
    'Riverside School District',
    'City Mall',
    'Tech Solutions Inc'
);