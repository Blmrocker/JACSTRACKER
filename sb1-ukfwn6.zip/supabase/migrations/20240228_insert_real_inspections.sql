-- Insert inspections based on notes
INSERT INTO inspections (
  client_id,
  inspection_date,
  location,
  inspector,
  status,
  notes
)
SELECT 
  id as client_id,
  '2024-01-01'::date as inspection_date, -- Using installation date from notes
  'Main Location' as location,
  'Jac' as inspector, -- Default inspector
  'completed' as status,
  'Initial installation and inspection' as notes
FROM clients
WHERE notes LIKE '%Installed%';