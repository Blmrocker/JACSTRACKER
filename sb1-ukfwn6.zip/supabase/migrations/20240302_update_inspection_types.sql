-- First, create a backup of the existing data
CREATE TABLE IF NOT EXISTS clients_backup AS SELECT * FROM clients;

-- Add the new column first (if it doesn't exist)
ALTER TABLE clients 
  ADD COLUMN IF NOT EXISTS inspection_types text[] DEFAULT '{}';

-- Only attempt to migrate data if the old column exists
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'clients' 
    AND column_name = 'inspection_type'
  ) THEN
    -- Migrate data from old column to new array column
    UPDATE clients c
    SET inspection_types = CASE 
      WHEN inspection_type IS NOT NULL AND inspection_type != '' 
      THEN ARRAY[inspection_type]
      ELSE '{}'::text[]
    END;

    -- Drop the old column
    ALTER TABLE clients DROP COLUMN inspection_type;
  END IF;
END $$;

-- Add an index for the array column to improve query performance
DROP INDEX IF EXISTS idx_clients_inspection_types;
CREATE INDEX idx_clients_inspection_types ON clients USING GIN (inspection_types);

-- Update RLS policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON clients;
DROP POLICY IF EXISTS "Enable write access for authenticated users" ON clients;

CREATE POLICY "Enable read access for authenticated users"
ON clients FOR SELECT
USING (auth.role() = 'authenticated');

CREATE POLICY "Enable write access for authenticated users"
ON clients FOR ALL
USING (auth.role() = 'authenticated')
WITH CHECK (auth.role() = 'authenticated');

-- Drop the backup table if everything is successful
DROP TABLE clients_backup;