-- Verify table structure
CREATE TABLE IF NOT EXISTS public.clients (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    name text NOT NULL,
    point_of_contact text,
    inspection_type text,
    frequency text,
    phone text,
    street_address text,
    city text,
    state text,
    zip_code text,
    email text,
    notes text,
    contract_start date,
    contract_end date,
    contract_amount decimal(10,2),
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Enable RLS but allow all operations for now (we'll restrict later)
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Enable all access for now" 
    ON public.clients 
    FOR ALL 
    USING (true)
    WITH CHECK (true);

-- Insert test client to verify
INSERT INTO public.clients (
    name,
    point_of_contact,
    inspection_type,
    frequency,
    phone,
    street_address,
    city,
    state,
    zip_code,
    email,
    notes,
    contract_start,
    contract_end,
    contract_amount
) VALUES (
    'Test Client',
    'John Doe',
    'FE',
    'Annual',
    '555-0123',
    '123 Test St',
    'Test City',
    'TX',
    '12345',
    'test@example.com',
    'Test notes',
    '2024-01-01',
    '2024-12-31',
    1000.00
);