-- Insert sample inspections
INSERT INTO inspections (
  id,
  client_id,
  inspection_date,
  location,
  inspector,
  status,
  notes,
  created_at,
  updated_at
)
SELECT 
  uuid_generate_v4(),
  id as client_id,
  '2024-03-15'::date as inspection_date,
  'Main Building' as location,
  'John Smith' as inspector,
  'completed' as status,
  'Annual inspection completed successfully' as notes,
  now() as created_at,
  now() as updated_at
FROM clients
WHERE name = 'Valley Medical Center'
UNION ALL
SELECT 
  uuid_generate_v4(),
  id as client_id,
  '2024-03-10'::date as inspection_date,
  'Tower A' as location,
  'Maria Rodriguez' as inspector,
  'completed' as status,
  'Quarterly inspection - all units checked' as notes,
  now() as created_at,
  now() as updated_at
FROM clients
WHERE name = 'Grand Hotel & Suites'
UNION ALL
SELECT 
  uuid_generate_v4(),
  id as client_id,
  '2024-03-20'::date as inspection_date,
  'Elementary School' as location,
  'David Johnson' as inspector,
  'scheduled' as status,
  'Regular maintenance inspection' as notes,
  now() as created_at,
  now() as updated_at
FROM clients
WHERE name = 'Riverside School District';