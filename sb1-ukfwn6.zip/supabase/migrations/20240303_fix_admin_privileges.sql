-- First, ensure the user_roles table exists and has proper constraints
CREATE TABLE IF NOT EXISTS public.user_roles (
  id uuid DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  role text CHECK (role IN ('admin', 'tech')) NOT NULL,
  phone_number text,
  notify_renewals boolean DEFAULT false,
  notify_inspections boolean DEFAULT false,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
  CONSTRAINT user_roles_user_id_key UNIQUE (user_id)
);

-- Enable RLS
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "admin_select_policy" ON public.user_roles;
DROP POLICY IF EXISTS "admin_insert_policy" ON public.user_roles;
DROP POLICY IF EXISTS "admin_update_policy" ON public.user_roles;
DROP POLICY IF EXISTS "admin_delete_policy" ON public.user_roles;

-- Create new RLS policies
CREATE POLICY "Enable read access for all authenticated users"
  ON public.user_roles FOR SELECT
  USING (auth.role() = 'authenticated');

CREATE POLICY "Enable write access for admins"
  ON public.user_roles FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_id = auth.uid()
      AND role = 'admin'
    )
    OR 
    auth.email() IN ('info@jacsfire.com', 'marcotonylopez90@gmail.com')
  );

-- Ensure admin privileges for specific emails
INSERT INTO public.user_roles (user_id, role, notify_renewals, notify_inspections)
SELECT 
  id as user_id,
  'admin' as role,
  true as notify_renewals,
  true as notify_inspections
FROM auth.users
WHERE email IN ('info@jacsfire.com', 'marcotonylopez90@gmail.com')
ON CONFLICT (user_id) 
DO UPDATE SET 
  role = 'admin',
  notify_renewals = true,
  notify_inspections = true;