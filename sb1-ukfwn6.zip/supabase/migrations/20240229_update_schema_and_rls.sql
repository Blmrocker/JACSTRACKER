-- First, update the inspections table schema
ALTER TABLE public.inspections
ADD COLUMN IF NOT EXISTS cover_page boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS files jsonb DEFAULT '[]'::jsonb;

-- Drop all existing RLS policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.inspections;
DROP POLICY IF EXISTS "Enable insert access for authenticated users" ON public.inspections;
DROP POLICY IF EXISTS "Enable update access for authenticated users" ON public.inspections;
DROP POLICY IF EXISTS "Enable delete access for authenticated users" ON public.inspections;

-- Create new RLS policies with proper authentication checks
CREATE POLICY "Enable read access for all authenticated users"
ON public.inspections FOR SELECT
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Enable insert access for all authenticated users"
ON public.inspections FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Enable update access for all authenticated users"
ON public.inspections FOR UPDATE
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Enable delete access for all authenticated users"
ON public.inspections FOR DELETE
USING (auth.uid() IS NOT NULL);

-- Create storage bucket for inspection files if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('inspection-files', 'inspection-files', false)
ON CONFLICT (id) DO NOTHING;

-- Set up storage policies
CREATE POLICY "Enable read access for authenticated users"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'inspection-files' 
  AND auth.uid() IS NOT NULL
);

CREATE POLICY "Enable insert access for authenticated users"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'inspection-files'
  AND auth.uid() IS NOT NULL
);

CREATE POLICY "Enable update access for authenticated users"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'inspection-files'
  AND auth.uid() IS NOT NULL
);

CREATE POLICY "Enable delete access for authenticated users"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'inspection-files'
  AND auth.uid() IS NOT NULL
);