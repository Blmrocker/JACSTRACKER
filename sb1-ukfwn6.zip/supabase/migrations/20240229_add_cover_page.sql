-- Add cover_page column to inspections table
ALTER TABLE public.inspections
ADD COLUMN cover_page boolean DEFAULT false;