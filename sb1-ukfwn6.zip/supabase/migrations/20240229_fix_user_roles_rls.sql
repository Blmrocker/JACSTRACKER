-- Drop existing RLS policies for user_roles
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.user_roles;
DROP POLICY IF EXISTS "Enable insert access for authenticated users" ON public.user_roles;
DROP POLICY IF EXISTS "Enable update access for authenticated users" ON public.user_roles;
DROP POLICY IF EXISTS "Enable delete access for authenticated users" ON public.user_roles;

-- Enable RLS on user_roles table
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create new RLS policies for user_roles
CREATE POLICY "Users can view own role"
ON public.user_roles FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create own role"
ON public.user_roles FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own role"
ON public.user_roles FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own role"
ON public.user_roles FOR DELETE
USING (auth.uid() = user_id);