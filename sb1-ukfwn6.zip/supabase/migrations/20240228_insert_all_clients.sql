-- Insert all clients with ON CONFLICT DO NOTHING to avoid duplicates
INSERT INTO clients (
    name,
    point_of_contact,
    inspection_type,
    frequency,
    phone,
    street_address,
    city,
    state,
    zip_code,
    email,
    notes,
    contract_start,
    contract_end,
    contract_amount
) VALUES
    (
        'Quest Diagnostics',
        'Elizabeth Meza',
        'FE',
        'Annual',
        NULL,
        '1201 E Ridge Rd',
        'McAllen',
        'TX',
        '78503',
        'elizabeth.x.meza@questdiagnostics.com',
        NULL,
        '2024-01-01',
        '2024-12-31',
        1200.00
    ),
    (
        'Alejandro''s',
        NULL,
        'FE',
        NULL,
        '956-782-9151',
        '2711 N Raul Longoria Rd',
        'San Juan',
        'TX',
        '78589',
        NULL,
        'Installed 2-5#ABC 2024',
        '2024-01-01',
        '2024-12-31',
        600.00
    ),
    (
        'O''Reilly',
        'Ramiro Castelan',
        'FE',
        'Annual',
        NULL,
        '4701 S. 23rd St.',
        'McAllen',
        'TX',
        '78503',
        NULL,
        'Installed 1-10#abc, 3-5#abc',
        '2024-01-01',
        '2024-12-31',
        900.00
    ),
    (
        'The Beauty Box',
        NULL,
        NULL,
        NULL,
        '956-888-9496',
        '204 S. FM 492 Suite 3',
        'Palmview',
        'TX',
        '78572',
        NULL,
        'Installed 1-5#abc',
        '2024-01-01',
        '2024-12-31',
        500.00
    ),
    (
        'Cavemen Barbershop',
        NULL,
        'FE',
        'Annual',
        '9565660946',
        '1451 W. Duranta Ave.',
        'Alamo',
        'TX',
        '78516',
        'Gabarber15@hotmail.com',
        NULL,
        '2024-01-01',
        '2024-12-31',
        500.00
    ),
    (
        'Valley Medical Center',
        'Dr. Sarah Johnson',
        'FE',
        'Annual',
        '(555) 123-4567',
        '789 Healthcare Ave',
        'Riverside',
        'CA',
        '92501',
        'sjohnson@valleymed.com',
        'Multiple buildings, requires coordination',
        '2024-01-01',
        '2024-12-31',
        4800.00
    ),
    (
        'Grand Hotel & Suites',
        'Michael Chen',
        'FE',
        'Quarterly',
        '(555) 234-5678',
        '456 Hospitality Blvd',
        'Riverside',
        'CA',
        '92502',
        'mchen@grandhotel.com',
        '15 story building',
        '2024-01-01',
        '2024-12-31',
        6000.00
    ),
    (
        'Riverside School District',
        'Amanda Martinez',
        'FE',
        'Annual',
        '(555) 345-6789',
        '123 Education St',
        'Riverside',
        'CA',
        '92503',
        'amartinez@rsd.edu',
        'Multiple schools in district',
        '2024-01-01',
        '2024-12-31',
        12000.00
    ),
    (
        'City Mall',
        'Robert Wilson',
        'FE',
        'Monthly',
        '(555) 456-7890',
        '321 Shopping Center Dr',
        'Riverside',
        'CA',
        '92504',
        'rwilson@citymall.com',
        'High traffic areas',
        '2024-01-01',
        '2024-12-31',
        8400.00
    ),
    (
        'Tech Solutions Inc',
        'Lisa Park',
        'FE',
        'Semi-Annual',
        '(555) 567-8901',
        '555 Innovation Way',
        'Riverside',
        'CA',
        '92505',
        'lpark@techsolutions.com',
        'Server rooms require special attention',
        '2024-01-01',
        '2024-12-31',
        3600.00
    )
ON CONFLICT (name) DO NOTHING;

-- Insert inspections for clients with installation notes
INSERT INTO inspections (
    client_id,
    inspection_date,
    location,
    inspector,
    status,
    notes
)
SELECT 
    id as client_id,
    '2024-01-01'::date as inspection_date,
    'Main Location' as location,
    'Jac' as inspector,
    'completed' as status,
    'Initial installation and inspection' as notes
FROM clients
WHERE notes LIKE '%Installed%'
AND NOT EXISTS (
    SELECT 1 FROM inspections i
    WHERE i.client_id = clients.id
    AND i.inspection_date = '2024-01-01'::date
);

-- Insert inspection items based on installation notes
WITH parsed_items AS (
    SELECT 
        i.id as inspection_id,
        c.notes,
        regexp_matches(c.notes, '(\d+)-(\d+)#(\w+)', 'g') as equipment_info
    FROM inspections i
    JOIN clients c ON c.id = i.client_id
    WHERE c.notes LIKE '%Installed%'
    AND NOT EXISTS (
        SELECT 1 FROM inspection_items ii
        WHERE ii.inspection_id = i.id
    )
)
INSERT INTO inspection_items (
    inspection_id,
    item_type,
    floor,
    room,
    equipment_type,
    status,
    notes
)
SELECT
    inspection_id,
    'Fire Extinguisher' as item_type,
    'Floor 1' as floor,
    'Main Area' as room,
    (equipment_info[2] || '#' || equipment_info[3])::text as equipment_type,
    'pass' as status,
    'Initial installation' as notes
FROM parsed_items;