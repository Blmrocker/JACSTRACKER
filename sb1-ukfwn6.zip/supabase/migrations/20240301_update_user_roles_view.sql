-- Enable RLS for user_roles table
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

-- Create policy to allow admins to view all users
CREATE POLICY "Allow admins to view all users"
ON user_roles
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid()
    AND role = 'admin'
  )
);

-- Create policy to allow users to view their own role
CREATE POLICY "Allow users to view own role"
ON user_roles
FOR SELECT
USING (user_id = auth.uid());

-- Create policy to allow admins to create users
CREATE POLICY "Allow admins to create users"
ON user_roles
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid()
    AND role = 'admin'
  )
);

-- Create policy to allow admins to update users
CREATE POLICY "Allow admins to update users"
ON user_roles
FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid()
    AND role = 'admin'
  )
);

-- Create policy to allow admins to delete users
CREATE POLICY "Allow admins to delete users"
ON user_roles
FOR DELETE
USING (
  EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid()
    AND role = 'admin'
  )
);