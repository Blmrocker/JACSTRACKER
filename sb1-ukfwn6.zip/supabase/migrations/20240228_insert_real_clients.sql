-- First clear existing data
DELETE FROM inspection_items;
DELETE FROM inspections;
DELETE FROM clients;

-- Insert actual clients from spreadsheet
INSERT INTO clients (
  name,
  point_of_contact,
  inspection_type,
  frequency,
  phone,
  street_address,
  city,
  state,
  zip_code,
  email,
  notes,
  contract_start,
  contract_end,
  contract_amount
) VALUES
  (
    'Quest Diagnostics',
    'Elizabeth Meza',
    'FE',
    'Annual',
    NULL,
    '1201 E Ridge Rd',
    'McAllen',
    'TX',
    '78503',
    'elizabeth.x.meza@questdiagnostics.com',
    NULL,
    '2024-01-01',
    '2024-12-31',
    1200.00
  ),
  (
    'Alejandro''s',
    NULL,
    'FE',
    NULL,
    '956-782-9151',
    '2711 N Raul Longoria Rd',
    'San Juan',
    'TX',
    '78589',
    NULL,
    'Installed 2-5#ABC 2024',
    '2024-01-01',
    '2024-12-31',
    600.00
  ),
  (
    'O''Reilly',
    'Ramiro Castelan',
    'FE',
    'Annual',
    NULL,
    '4701 S. 23rd St.',
    'McAllen',
    'TX',
    '78503',
    NULL,
    'Installed 1-10#abc, 3-5#abc',
    '2024-01-01',
    '2024-12-31',
    900.00
  ),
  (
    'The Beauty Box',
    NULL,
    NULL,
    NULL,
    '956-888-9496',
    '204 S. FM 492 Suite 3',
    'Palmview',
    'TX',
    '78572',
    NULL,
    'Installed 1-5#abc',
    '2024-01-01',
    '2024-12-31',
    500.00
  ),
  (
    'Cavemen Barbershop',
    NULL,
    'FE',
    'Annual',
    '9565660946',
    '1451 W. Duranta Ave.',
    'Alamo',
    'TX',
    '78516',
    'Gabarber15@hotmail.com',
    NULL,
    '2024-01-01',
    '2024-12-31',
    500.00
  );