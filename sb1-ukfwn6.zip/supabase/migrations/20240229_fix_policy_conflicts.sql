-- First, drop ALL existing policies to avoid conflicts
DO $$ 
BEGIN
    -- Drop inspection policies
    DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.inspections;
    DROP POLICY IF EXISTS "Enable insert access for authenticated users" ON public.inspections;
    DROP POLICY IF EXISTS "Enable update access for authenticated users" ON public.inspections;
    DROP POLICY IF EXISTS "Enable delete access for authenticated users" ON public.inspections;
    DROP POLICY IF EXISTS "Enable read access for all authenticated users" ON public.inspections;
    DROP POLICY IF EXISTS "Users can view inspections" ON public.inspections;
    DROP POLICY IF EXISTS "Users can insert inspections" ON public.inspections;
    DROP POLICY IF EXISTS "Users can update inspections" ON public.inspections;
    DROP POLICY IF EXISTS "Users can delete inspections" ON public.inspections;

    -- Drop inspection_items policies
    DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.inspection_items;
    DROP POLICY IF EXISTS "Enable insert access for authenticated users" ON public.inspection_items;
    DROP POLICY IF EXISTS "Enable update access for authenticated users" ON public.inspection_items;
    DROP POLICY IF EXISTS "Enable delete access for authenticated users" ON public.inspection_items;
    DROP POLICY IF EXISTS "Users can view inspection items" ON public.inspection_items;
    DROP POLICY IF EXISTS "Users can insert inspection items" ON public.inspection_items;
    DROP POLICY IF EXISTS "Users can update inspection items" ON public.inspection_items;
    DROP POLICY IF EXISTS "Users can delete inspection items" ON public.inspection_items;
END $$;

-- Ensure RLS is enabled
ALTER TABLE public.inspections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inspection_items ENABLE ROW LEVEL SECURITY;

-- Create new policies for inspections with unique names
CREATE POLICY "inspection_select_policy" ON public.inspections
    FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "inspection_insert_policy" ON public.inspections
    FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "inspection_update_policy" ON public.inspections
    FOR UPDATE USING (auth.uid() IS NOT NULL);

CREATE POLICY "inspection_delete_policy" ON public.inspections
    FOR DELETE USING (auth.uid() IS NOT NULL);

-- Create new policies for inspection_items with unique names
CREATE POLICY "inspection_items_select_policy" ON public.inspection_items
    FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "inspection_items_insert_policy" ON public.inspection_items
    FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "inspection_items_update_policy" ON public.inspection_items
    FOR UPDATE USING (auth.uid() IS NOT NULL);

CREATE POLICY "inspection_items_delete_policy" ON public.inspection_items
    FOR DELETE USING (auth.uid() IS NOT NULL);

-- Ensure storage policies are unique
DO $$ 
BEGIN
    -- Drop existing storage policies if they exist
    DROP POLICY IF EXISTS "Enable read access for authenticated users" ON storage.objects;
    DROP POLICY IF EXISTS "Enable insert access for authenticated users" ON storage.objects;
    DROP POLICY IF EXISTS "Enable update access for authenticated users" ON storage.objects;
    DROP POLICY IF EXISTS "Enable delete access for authenticated users" ON storage.objects;
EXCEPTION
    WHEN undefined_object THEN NULL;
END $$;

-- Create storage policies with unique names
CREATE POLICY "storage_inspection_files_select" ON storage.objects
    FOR SELECT USING (bucket_id = 'inspection-files' AND auth.uid() IS NOT NULL);

CREATE POLICY "storage_inspection_files_insert" ON storage.objects
    FOR INSERT WITH CHECK (bucket_id = 'inspection-files' AND auth.uid() IS NOT NULL);

CREATE POLICY "storage_inspection_files_update" ON storage.objects
    FOR UPDATE USING (bucket_id = 'inspection-files' AND auth.uid() IS NOT NULL);

CREATE POLICY "storage_inspection_files_delete" ON storage.objects
    FOR DELETE USING (bucket_id = 'inspection-files' AND auth.uid() IS NOT NULL);