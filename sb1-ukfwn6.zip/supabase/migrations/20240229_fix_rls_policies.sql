-- Drop existing RLS policies for inspections
DROP POLICY IF EXISTS "Users can view inspections" ON public.inspections;
DROP POLICY IF EXISTS "Users can insert inspections" ON public.inspections;
DROP POLICY IF EXISTS "Users can update inspections" ON public.inspections;
DROP POLICY IF EXISTS "Users can delete inspections" ON public.inspections;

-- Enable RLS on inspections table
ALTER TABLE public.inspections ENABLE ROW LEVEL SECURITY;

-- Create new RLS policies for inspections
CREATE POLICY "Enable read access for authenticated users"
ON public.inspections FOR SELECT
USING (auth.role() = 'authenticated');

CREATE POLICY "Enable insert access for authenticated users"
ON public.inspections FOR INSERT
WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Enable update access for authenticated users"
ON public.inspections FOR UPDATE
USING (auth.role() = 'authenticated');

CREATE POLICY "Enable delete access for authenticated users"
ON public.inspections FOR DELETE
USING (auth.role() = 'authenticated');

-- Drop existing RLS policies for inspection_items
DROP POLICY IF EXISTS "Users can view inspection items" ON public.inspection_items;
DROP POLICY IF EXISTS "Users can insert inspection items" ON public.inspection_items;
DROP POLICY IF EXISTS "Users can update inspection items" ON public.inspection_items;
DROP POLICY IF EXISTS "Users can delete inspection items" ON public.inspection_items;

-- Enable RLS on inspection_items table
ALTER TABLE public.inspection_items ENABLE ROW LEVEL SECURITY;

-- Create new RLS policies for inspection_items
CREATE POLICY "Enable read access for authenticated users"
ON public.inspection_items FOR SELECT
USING (auth.role() = 'authenticated');

CREATE POLICY "Enable insert access for authenticated users"
ON public.inspection_items FOR INSERT
WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Enable update access for authenticated users"
ON public.inspection_items FOR UPDATE
USING (auth.role() = 'authenticated');

CREATE POLICY "Enable delete access for authenticated users"
ON public.inspection_items FOR DELETE
USING (auth.role() = 'authenticated');