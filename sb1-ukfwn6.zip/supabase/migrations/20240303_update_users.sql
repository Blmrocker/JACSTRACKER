-- First, clear existing user roles
DELETE FROM user_roles;

-- Insert initial admin users
INSERT INTO user_roles (
  user_id,
  role,
  notify_renewals,
  notify_inspections
)
SELECT 
  id as user_id,
  'admin' as role,
  true as notify_renewals,
  true as notify_inspections
FROM auth.users
WHERE email IN ('info@jacsfire.com', 'marcotonylopez90@gmail.com')
ON CONFLICT (user_id) DO UPDATE 
SET role = 'admin',
    notify_renewals = true,
    notify_inspections = true;