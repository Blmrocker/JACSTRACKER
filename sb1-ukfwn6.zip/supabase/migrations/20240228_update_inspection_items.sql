-- Insert inspection items based on updated notes
WITH parsed_items AS (
  SELECT 
    i.id as inspection_id,
    c.notes,
    regexp_matches(c.notes, '(\d+)-(\d+)#(\w+)', 'g') as equipment_info
  FROM inspections i
  JOIN clients c ON c.id = i.client_id
  WHERE c.notes LIKE '%Installed%'
)
INSERT INTO inspection_items (
  inspection_id,
  item_type,
  floor,
  room,
  equipment_type,
  status,
  notes
)
SELECT DISTINCT
  inspection_id,
  'Fire Extinguisher' as item_type,
  'Floor 1' as floor, -- Default to first floor
  'Main Area' as room, -- Default room
  (equipment_info[2] || '#' || equipment_info[3])::text as equipment_type,
  'pass' as status, -- New installations are assumed to pass
  'Initial installation' as notes
FROM parsed_items
ON CONFLICT DO NOTHING;