-- Drop existing foreign key constraint if it exists
ALTER TABLE IF EXISTS user_roles
DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;

-- Add the foreign key constraint with proper reference
ALTER TABLE user_roles
ADD CONSTRAINT user_roles_user_id_fkey
FOREIGN KEY (user_id)
REFERENCES auth.users(id)
ON DELETE CASCADE;