import { z } from 'zod';

export const companySchema = z.object({
  name: z.string().optional(),
  address: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email('Invalid email address').optional().nullable(),
  website: z.string().url('Invalid website URL').optional().nullable(),
  logo_url: z.string().optional(),
});

export type CompanyFormData = z.infer<typeof companySchema>;

// Other validation schemas remain the same...